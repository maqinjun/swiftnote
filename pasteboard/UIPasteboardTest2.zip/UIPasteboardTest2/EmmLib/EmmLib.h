//
//  EmmLib.h
//  EmmLib
//
//  Created by dengxiang on 2/25/16.
//  Copyright © 2016 uusafe. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface EmmLib : NSObject
+ (void)pasteboardHookEnable:(BOOL)is;
@end
