//
//  ContactsHook.h
//  EmmLib
//
//  Created by dengxiang on 3/1/16.
//  Copyright © 2016 uusafe. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ContactsHook : NSObject
+ (void) hook;
@end
